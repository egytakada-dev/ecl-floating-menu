package com.example.floatingmenu;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {

    private TextView statusText;
    private Button grantButton;
    private Button toggleButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        statusText = findViewById(R.id.statusText);
        grantButton = findViewById(R.id.grantButton);
        toggleButton = findViewById(R.id.toggleButton);

        grantButton.setOnClickListener(v -> openOverlaySettings());
        toggleButton.setOnClickListener(v -> onToggleClicked());

        // Android 13+: izin notifikasi agar notifikasi foreground service terlihat.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshUi();
    }

    private void refreshUi() {
        boolean canDraw = Settings.canDrawOverlays(this);
        boolean running = OverlayService.isRunning();

        grantButton.setVisibility(canDraw ? View.GONE : View.VISIBLE);
        toggleButton.setText(running ? R.string.btn_stop : R.string.btn_start);
        statusText.setText(!canDraw ? R.string.status_need_permission
                : running ? R.string.status_running : R.string.status_ready);
    }

    private void onToggleClicked() {
        if (OverlayService.isRunning()) {
            stopService(new Intent(this, OverlayService.class));
            toggleButton.postDelayed(this::refreshUi, 300);
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            openOverlaySettings();
            return;
        }
        Intent intent = new Intent(this, OverlayService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }
        // Kirim aplikasi ke latar belakang agar menu terlihat melayang di atas aplikasi lain.
        moveTaskToBack(true);
    }

    private void openOverlaySettings() {
        Uri uri = Uri.parse("package:" + getPackageName());
        try {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, uri));
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));
        }
    }
}
