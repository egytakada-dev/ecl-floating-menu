package com.example.floatingmenu;

/**
 * Adapter boundary for a game-specific integration module.
 *
 * This interface is intentionally not implemented by the standalone overlay app:
 * the game APK and its exact version must be inspected before any feature can be
 * safely and correctly connected.
 *
 * A compatible integration module can register an implementation using
 * Features.attachAdapter(...).
 */
public interface GameFeatureAdapter {
    /**
     * @param featureIndex 0=Radar, 1=Night Vision,
     *                     2=Value Not Decrease, 3=Maximum XP
     * @param enabled whether the feature should be enabled
     * @return true only when the game-side feature was actually applied
     */
    boolean apply(int featureIndex, boolean enabled);
}
