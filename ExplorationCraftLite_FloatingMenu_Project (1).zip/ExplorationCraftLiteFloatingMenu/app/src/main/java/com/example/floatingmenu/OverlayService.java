package com.example.floatingmenu;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Menu mengambang: gelembung yang bisa diseret. Ketuk untuk membuka panel berisi saklar ON/OFF.
 * Berjalan sebagai foreground service supaya tetap hidup di latar belakang.
 */
public class OverlayService extends Service {

    public static final String ACTION_STOP = "com.example.floatingmenu.ACTION_STOP";

    private static final String CHANNEL_ID = "floating_menu_channel";
    private static final int NOTIFICATION_ID = 1;

    private static volatile boolean running = false;

    public static boolean isRunning() {
        return running;
    }

    private WindowManager windowManager;
    private WindowManager.LayoutParams params;
    private LinearLayout root;
    private ImageView bubble;
    private LinearLayout panel;
    private boolean attached = false;
    private int touchSlop;

    private String[] labels;
    private boolean[] states;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        running = true;
        touchSlop = ViewConfiguration.get(this).getScaledTouchSlop();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        startAsForeground();
        if (!attached) {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, R.string.status_need_permission, Toast.LENGTH_LONG).show();
                stopSelf();
                return START_NOT_STICKY;
            }
            showOverlay();
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        if (attached) {
            try {
                windowManager.removeView(root);
            } catch (IllegalArgumentException ignored) {
                // sudah terlepas
            }
            attached = false;
        }
        // Menu dimatikan -> semua saklar yang masih ON dikembalikan ke OFF.
        if (states != null) {
            for (int i = 0; i < states.length; i++) {
                if (states[i]) {
                    states[i] = false;
                    try {
                        Features.onToggle(this, i, false);
                    } catch (RuntimeException ignored) {
                        // jangan sampai error di logika saklar menghalangi service berhenti
                    }
                }
            }
        }
        running = false;
        super.onDestroy();
    }

    // ---------------------------------------------------------------- notifikasi

    private void startAsForeground() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(new NotificationChannel(
                    CHANNEL_ID, getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW));
        }

        PendingIntent openIntent = PendingIntent.getActivity(
                this, 0, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stopIntent = PendingIntent.getService(
                this, 1, new Intent(this, OverlayService.class).setAction(ACTION_STOP),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);

        builder.setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(getString(R.string.notif_title))
                .setContentText(getString(R.string.notif_text))
                .setContentIntent(openIntent)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(
                        Icon.createWithResource(this, R.drawable.ic_notification),
                        getString(R.string.menu_stop),
                        stopIntent).build());

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            builder.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        }

        startForeground(NOTIFICATION_ID, builder.build());
    }

    // ---------------------------------------------------------------- tampilan overlay

    private void showOverlay() {
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        Context ui = new ContextThemeWrapper(this, android.R.style.Theme_Material);

        labels = getResources().getStringArray(R.array.feature_labels);
        states = new boolean[labels.length];

        // Gelembung (kondisi tertutup)
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(0xF02563EB);

        bubble = new ImageView(ui);
        bubble.setImageResource(R.drawable.ic_notification);
        bubble.setBackground(circle);
        bubble.setPadding(dp(14), dp(14), dp(14), dp(14));
        bubble.setOnTouchListener(new DragListener(() -> setExpanded(true)));

        // Panel (kondisi terbuka)
        GradientDrawable panelBg = new GradientDrawable();
        panelBg.setColor(0xF2111827);
        panelBg.setCornerRadius(dp(16));

        panel = new LinearLayout(ui);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(panelBg);
        panel.setPadding(dp(16), dp(10), dp(16), dp(12));
        panel.setVisibility(View.GONE);
        panel.addView(buildHeader(ui));
        for (int i = 0; i < labels.length; i++) {
            panel.addView(buildRow(ui, i));
        }
        panel.addView(buildStopButton(ui));

        root = new LinearLayout(ui);
        root.setOrientation(LinearLayout.VERTICAL);
        root.addView(bubble, new LinearLayout.LayoutParams(dp(52), dp(52)));
        root.addView(panel, new LinearLayout.LayoutParams(
                dp(240), LinearLayout.LayoutParams.WRAP_CONTENT));

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        // NOT_FOCUSABLE + NOT_TOUCH_MODAL: sentuhan di luar menu tetap diterima aplikasi di belakangnya.
        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.LEFT;
        params.x = dp(16);
        params.y = dp(160);

        try {
            windowManager.addView(root, params);
            attached = true;
        } catch (RuntimeException e) {
            Toast.makeText(this, R.string.status_overlay_failed, Toast.LENGTH_LONG).show();
            stopSelf();
        }
    }

    private View buildHeader(Context ui) {
        LinearLayout header = new LinearLayout(ui);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setOnTouchListener(new DragListener(null)); // seret panel lewat judulnya

        TextView title = new TextView(ui);
        title.setText(R.string.menu_title);
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        header.addView(title, new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView collapse = new TextView(ui);
        collapse.setText("\u2013");
        collapse.setTextColor(Color.WHITE);
        collapse.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        collapse.setGravity(Gravity.CENTER);
        collapse.setPadding(dp(16), dp(2), dp(4), dp(2));
        collapse.setOnClickListener(v -> setExpanded(false));
        header.addView(collapse, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        return header;
    }

    private View buildRow(Context ui, final int index) {
        LinearLayout row = new LinearLayout(ui);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(6), 0, dp(6));

        TextView label = new TextView(ui);
        label.setText(labels[index]);
        label.setTextColor(Color.WHITE);
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        row.addView(label, new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        Switch toggle = new Switch(ui);
        toggle.setThumbTintList(stateList(Color.WHITE, 0xFFD1D5DB));
        toggle.setTrackTintList(stateList(0xFF2563EB, 0xFF6B7280));
        toggle.setOnCheckedChangeListener((button, checked) -> {
            states[index] = checked;
            Features.onToggle(this, index, checked);
        });
        row.addView(toggle);
        return row;
    }

    private View buildStopButton(Context ui) {
        TextView stop = new TextView(ui);
        stop.setText(R.string.menu_stop);
        stop.setTextColor(0xFFFCA5A5);
        stop.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        stop.setGravity(Gravity.CENTER);
        stop.setPadding(0, dp(12), 0, dp(4));
        stop.setOnClickListener(v -> stopSelf());
        return stop;
    }

    private static ColorStateList stateList(int checked, int unchecked) {
        return new ColorStateList(
                new int[][]{new int[]{android.R.attr.state_checked}, new int[0]},
                new int[]{checked, unchecked});
    }

    private void setExpanded(boolean expanded) {
        bubble.setVisibility(expanded ? View.GONE : View.VISIBLE);
        panel.setVisibility(expanded ? View.VISIBLE : View.GONE);

        DisplayMetrics dm = getResources().getDisplayMetrics();
        root.measure(
                View.MeasureSpec.makeMeasureSpec(dm.widthPixels, View.MeasureSpec.AT_MOST),
                View.MeasureSpec.makeMeasureSpec(dm.heightPixels, View.MeasureSpec.AT_MOST));
        clampToScreen(root.getMeasuredWidth(), root.getMeasuredHeight());
        windowManager.updateViewLayout(root, params);
    }

    private void clampToScreen(int viewW, int viewH) {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int maxX = dm.widthPixels - viewW;
        int maxY = dm.heightPixels - viewH - dp(48);
        params.x = Math.max(0, Math.min(params.x, maxX));
        params.y = Math.max(0, Math.min(params.y, maxY));
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    /** Menyeret jendela overlay; sentuhan singkat tanpa geser dianggap ketukan (onTap). */
    private class DragListener implements View.OnTouchListener {
        private final Runnable onTap;
        private int startX;
        private int startY;
        private float downX;
        private float downY;
        private boolean dragging;

        DragListener(Runnable onTap) {
            this.onTap = onTap;
        }

        @Override
        public boolean onTouch(View v, MotionEvent event) {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN: {
                    startX = params.x;
                    startY = params.y;
                    downX = event.getRawX();
                    downY = event.getRawY();
                    dragging = false;
                    return true;
                }
                case MotionEvent.ACTION_MOVE: {
                    float dx = event.getRawX() - downX;
                    float dy = event.getRawY() - downY;
                    if (!dragging && Math.hypot(dx, dy) > touchSlop) {
                        dragging = true;
                    }
                    if (dragging) {
                        params.x = startX + Math.round(dx);
                        params.y = startY + Math.round(dy);
                        clampToScreen(root.getWidth(), root.getHeight());
                        windowManager.updateViewLayout(root, params);
                    }
                    return true;
                }
                case MotionEvent.ACTION_UP: {
                    if (!dragging && onTap != null) {
                        onTap.run();
                    }
                    return true;
                }
                default:
                    return true;
            }
        }
    }
}
