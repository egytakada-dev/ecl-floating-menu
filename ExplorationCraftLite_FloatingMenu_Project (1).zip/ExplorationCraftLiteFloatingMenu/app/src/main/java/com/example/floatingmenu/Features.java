package com.example.floatingmenu;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

/**
 * Routes overlay switches to an optional game integration adapter.
 *
 * The base project has no game adapter yet, so the switches operate the menu UI
 * only. This class deliberately does not claim to change game state.
 */
public final class Features {

    private static final String TAG = "ECLFloatingMenu";
    private static volatile GameFeatureAdapter adapter;

    private Features() {
    }

    /** Called by a compatible game-side integration module when it is available. */
    public static void attachAdapter(GameFeatureAdapter gameAdapter) {
        adapter = gameAdapter;
        Log.i(TAG, gameAdapter == null
                ? "Game adapter detached"
                : "Game adapter attached");
    }

    /**
     * Called on the main thread whenever one of the four switches changes.
     * index: 0 Radar, 1 Night Vision, 2 Value Not Decrease, 3 Maximum XP.
     */
    public static void onToggle(Context context, int index, boolean enabled) {
        String[] labels = context.getResources().getStringArray(R.array.feature_labels);
        String name = index >= 0 && index < labels.length
                ? labels[index] : "Feature " + (index + 1);

        GameFeatureAdapter currentAdapter = adapter;
        boolean applied = false;
        if (currentAdapter != null) {
            try {
                applied = currentAdapter.apply(index, enabled);
            } catch (RuntimeException error) {
                Log.e(TAG, "Game adapter error for " + name, error);
            }
        }

        String state = enabled ? "ON" : "OFF";
        if (applied) {
            Log.i(TAG, name + " -> " + state + " (applied)");
            Toast.makeText(context, name + ": " + state, Toast.LENGTH_SHORT).show();
        } else {
            Log.i(TAG, name + " -> " + state
                    + " (menu only; game adapter not connected)");
            Toast.makeText(
                    context,
                    name + ": " + state + " — integrasi game belum tersedia",
                    Toast.LENGTH_LONG
            ).show();
        }
    }
}
