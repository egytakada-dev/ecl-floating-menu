# ECL Floating Menu — Android Studio project

Proyek ini berasal dari `FloatingMenuTemplate.zip` dan sudah diubah labelnya untuk
Exploration Craft Lite:

1. Radar
2. Night Vision
3. Value Not Decrease
4. Maximum XP

## Fitur yang sudah tersedia
- Gelembung overlay yang bisa dipindahkan.
- Panel dengan empat saklar ON/OFF.
- Foreground service agar menu tetap tampil saat berpindah aplikasi.
- Izin overlay dan notifikasi sesuai template asal.
- Titik integrasi `GameFeatureAdapter` untuk modul game yang kompatibel.

## Batasan penting
Empat saklar di proyek dasar ini **belum mengubah keadaan game**. `Features.java`
hanya meneruskan status toggle ke `GameFeatureAdapter`; belum ada adapter game yang
terpasang. Karena itu menu akan menampilkan pesan bahwa integrasi game belum tersedia.

Radar (klasifikasi entity dan garis merah/hijau), Night Vision, pengubahan saldo
Koin/Gem, serta Maximum XP memerlukan identifikasi struktur dan mekanisme game pada
APK/XAPK Exploration Craft Lite yang tepat. Jangan menganggap toggle berfungsi hanya
karena indikatornya berubah menjadi ON.

## Cara build
1. Ekstrak ZIP proyek.
2. Buka folder `ExplorationCraftLiteFloatingMenu` melalui Android Studio.
3. Tunggu Gradle sync selesai.
4. Pilih **Build > Build APK(s)**.
5. Pasang APK hasil build, beri izin **tampil di atas aplikasi lain**, lalu tekan Mulai.

Konfigurasi: Android Gradle Plugin 8.5.2, Gradle 8.7, Java 17, compile SDK 34,
minimum Android 7.0 (API 24).

## Berkas integrasi
- `app/src/main/res/values/strings.xml`: label aplikasi dan empat opsi.
- `app/src/main/java/com/example/floatingmenu/OverlayService.java`: overlay.
- `app/src/main/java/com/example/floatingmenu/Features.java`: pengarah toggle.
- `app/src/main/java/com/example/floatingmenu/GameFeatureAdapter.java`: kontrak adapter game.

Untuk integrasi fitur yang nyata, diperlukan APK/XAPK target dan nomor versinya.
