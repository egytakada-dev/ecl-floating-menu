# Catatan integrasi game

Belum ada implementasi fitur game di proyek ini. Adapter baru boleh dipasang setelah
APK target dianalisis dan perilaku internal masing-masing fitur sudah terverifikasi.

Kontrak indeks:
- 0: Radar — butuh data entity, klasifikasi perilaku/agresi, dan koordinat layar.
- 1: Night Vision — butuh jalur rendering/lighting yang benar pada game.
- 2: Value Not Decrease — butuh identifikasi transaksi Koin dan Gem serta aturan penyimpanannya.
- 3: Maximum XP — butuh identifikasi sistem XP, batas nilai, dan konsistensi penyimpanan.

`GameFeatureAdapter.apply(index, enabled)` wajib mengembalikan `true` hanya setelah
perubahan game benar-benar diterapkan. Jangan mengembalikan `true` untuk toggle UI saja.
